tinyMCE.addI18n('pt_PT', {
  'Insert an image from your computer': 'Inserir uma imagem do seu computador',
  'Insert image': 'Inserir imagem',
  'Choose an image': "Escolher uma imagem",
  'You must choose a file': "É necessário seleccionar um ficheiro",
  'Got a bad response from the server': "Resposta inesperada do servidor",
  "Didn't get a response from the server": "Não foi obtida uma resposta do servidor",
  'Insert': "Inserir",
  'Cancel': "Cancelar",
  'Image description': "Descrição da imagem",
});
